# Eq1 > 2024-09-17 3:34pm
https://universe.roboflow.com/iiot-vdbko/eq1

Provided by a Roboflow user
License: CC BY 4.0

